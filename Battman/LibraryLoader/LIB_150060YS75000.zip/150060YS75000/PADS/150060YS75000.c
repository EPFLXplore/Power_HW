*PADS-LIBRARY-SCH-DECALS-V9*

150060YS75000         32000 32000 100 10 100 10 4 8 0 2 8
TIMESTAMP 2020.10.16.10.28.02
"Default Font"
"Default Font"
500   350   0 0 100 10 "Default Font"
REF-DES
500   250   0 0 100 10 "Default Font"
PART-TYPE
500   -200  0 0 100 10 "Default Font"
*
500   -300  0 0 100 10 "Default Font"
*
COPCLS 4 10 0 -1
200   0    
400   100  
400   -100 
200   0    
OPEN   2 10 0 -1
200   100  
200   -100 
OPEN   2 10 0 -1
250   100  
150   200  
COPCLS 4 10 0 -1
210   170  
180   140  
150   200  
210   170  
OPEN   2 10 0 -1
350   100  
250   200  
COPCLS 4 10 0 -1
310   170  
280   140  
250   200  
310   170  
OPEN   2 10 0 -1
100   0    
200   0    
OPEN   2 10 0 -1
400   0    
500   0    
T0     0     0 0 60    10    0 2 10    -10   0 32 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T600   0     0 2 60    10    0 2 10    -10   0 32 PINSHORT
P-520  0     0 2 -80   0     0 2 0


*END*