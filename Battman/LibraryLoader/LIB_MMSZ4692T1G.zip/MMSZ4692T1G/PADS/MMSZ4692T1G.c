*PADS-LIBRARY-SCH-DECALS-V9*

MMSZ4692T1G      32000 32000 100 10 100 10 4 6 0 2 8
TIMESTAMP 2020.10.26.07.11.30
"Default Font"
"Default Font"
400   350   0 8 100 10 "Default Font"
REF-DES
400   250   0 8 100 10 "Default Font"
PART-TYPE
400   -200  0 0 100 10 "Default Font"
*
400   -300  0 0 100 10 "Default Font"
*
COPCLS 4 10 0 -1
200   0    
400   100  
400   -100 
200   0    
OPEN   2 10 0 -1
200   80   
200   -80  
OPEN   2 10 0 -1
200   80   
240   100  
OPEN   2 10 0 -1
160   -100 
200   -80  
OPEN   2 10 0 -1
100   0    
200   0    
OPEN   2 10 0 -1
500   0    
400   0    
T0     0     0 0 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T600   0     0 2 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0

*END*